/*
* Copyright (c) 2013-2015 Freescale Semiconductor, Inc.
* All rights reserved.
*
* SPDX-License-Identifier: BSD-3-Clause
*/

#include "stdafx.h"
#include "HistoryData.h"

// See HistoryData.h for documentation of this variable.
HistoryData *g_pHistoryData;
